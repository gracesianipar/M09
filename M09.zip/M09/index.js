const express = require('express')
const bodyParser = require('body-parser');
const app = express();
const mysql = require('mysql2');

// parse application/json
app.use(bodyParser.json());

//create database connection
const conn = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'crud_db'
});

// connect to databse
conn.connect((err) =>{
  if(err) throw err;
  console.log('Mysql Connected...');
});

//tampilkan semua data product
app.get('/api/products',(req, res) => {
  let sql = "SELECT * FROM products";
  let query = conn.query(sql, (err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});

// tampilkam data product berdasrkan id
app.get('/api/products/:id',(req, res) => {
  let sql = "SELECT * FROM products WHERE product_id="+req.params.id;
  let query = conn.query(sql, (err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});

// tambahkan data product baru
app.post('/api/products', (req, res) => {
  let data = {product_name: req.body.product_name, product_price: req.body.product_proce};
  let sql = "INSERT INTO product SET ?";
  let query = conn.query(sql, data,(err, status) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});

// edit data product bedasarkan id
app.put('api/products/:id', (req, res) => {
  let sql = "UPDATE products SET product_name='"+req.body.product_name+"', product_price='"+req.body.product_price+"' WHERE product_id="+req.params.id;
  let query = conn.query(sql, (err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": "Update data success"}));
  });
});

// delete data product berdasarkan id
app.delete('/api/products/:id',(req,res) => {
  let sql = "DELETE FROM products WHERE product_id="+req.params.id+"";
  let query = conn.query(sql, (err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": "Delete data success"}));
  });
});

// server listening
app.listen(3000,() =>{
  console.log("Server started on port 3000...")
});